Hébergeur FiveM Vraiment pas chers c'est ici -> http://fiveheberg.fr/ <br>
Discord de FiveHeberg.fr -> https://discord.gg/M7dxBymgVH

Vidéo d'installation: https://www.youtube.com/watch?v=GIZQn3fxoS8

<img src="https://i.goopics.net/Gda8p.png">

Aujourd'hui je décide de Leak un ancien site web que j'avais développé pour GrandParisRP
C'est un site LeBonCoin comme "IRL" il consiste de vendre vos véhicules pour tous les joueurs et un système d'enchère est mis à disposition (Selon vos grades sur le site).

Un panel staff est compris dans le site avec plusieurs grades.

Installation du panel:
Upload le sql.sql dans PhpMyAdmin
Configurer vos donnés mysql dans le fichier de configuration suivant:
LeBonCoin\configuration\connect.php


PS: Merci de ne pas retirer les copyrights
Bonne journée

<img src="https://i.goopics.net/0OKmw.png">
